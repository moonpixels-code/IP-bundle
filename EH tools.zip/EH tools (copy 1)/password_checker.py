#!/usr/bin/env python3

import json
import re
from datetime import datetime
from colorama import Fore, Style, init

init()


def banner():

    print(Fore.CYAN + r"""

██████╗  █████╗ ███████╗███████╗
██╔══██╗██╔══██╗██╔════╝██╔════╝
██████╔╝███████║███████╗███████╗
██╔═══╝ ██╔══██║╚════██║╚════██║
██║     ██║  ██║███████║███████║
╚═╝     ╚═╝  ╚═╝╚══════╝╚══════╝

     PASSWORD STRENGTH CHECKER v1.0

""" + Style.RESET_ALL)



def check_password(password):

    score = 0
    issues = []
    suggestions = []


    if len(password) >= 12:
        score += 2
    elif len(password) >= 8:
        score += 1
    else:
        issues.append("Password is too short")
        suggestions.append("Use at least 12 characters")


    if re.search("[A-Z]", password):
        score += 1
    else:
        issues.append("No uppercase letters")
        suggestions.append("Add uppercase letters")


    if re.search("[a-z]", password):
        score += 1
    else:
        issues.append("No lowercase letters")
        suggestions.append("Add lowercase letters")


    if re.search("[0-9]", password):
        score += 1
    else:
        issues.append("No numbers")
        suggestions.append("Add numbers")


    if re.search("[!@#$%^&*(),.?\":{}|<>]", password):
        score += 1
    else:
        issues.append("No symbols")
        suggestions.append("Add special characters")


    common = [
        "password",
        "123456",
        "qwerty",
        "admin"
    ]


    if password.lower() in common:
        score = 0
        issues.append("Common password detected")


    if score <= 2:
        strength = "Weak"

    elif score <= 4:
        strength = "Medium"

    else:
        strength = "Strong"



    result = {

        "Password Length": len(password),
        "Score": score,
        "Strength": strength,
        "Issues": issues,
        "Suggestions": suggestions,
        "Checked": str(datetime.now())

    }


    return result



banner()


password = input(
    Fore.YELLOW +
    "Enter password to check: "
    +
    Style.RESET_ALL
)


result = check_password(password)



print(
    Fore.GREEN +
    "\n=== Password Report ==="
)


print(
    Fore.CYAN +
    "Strength:",
    result["Strength"]
)


print(
    Fore.CYAN +
    "Score:",
    result["Score"]
)


if result["Issues"]:

    print(
        Fore.RED +
        "\nIssues:"
    )

    for item in result["Issues"]:
        print("-", item)



if result["Suggestions"]:

    print(
        Fore.YELLOW +
        "\nSuggestions:"
    )

    for item in result["Suggestions"]:
        print("-", item)



with open(
    "report.json",
    "w"
) as file:

    json.dump(
        result,
        file,
        indent=4
    )


print(
    Fore.GREEN +
    "\n[+] Report saved as report.json"
)
