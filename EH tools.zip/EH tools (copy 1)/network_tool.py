#!/usr/bin/env python3

import socket
import json
import requests
from datetime import datetime
from colorama import Fore, Style, init

init(autoreset=True)


def banner():
    print(Fore.CYAN + r"""

███╗   ██╗███████╗████████╗
████╗  ██║██╔════╝╚══██╔══╝
██╔██╗ ██║█████╗     ██║
██║╚██╗██║██╔══╝     ██║
██║ ╚████║███████╗   ██║
╚═╝  ╚═══╝╚══════╝   ╚═╝

██╗███╗   ██╗███████╗ ██████╗
██║████╗  ██║██╔════╝██╔═══██╗
██║██╔██╗ ██║█████╗  ██║   ██║
██║██║╚██╗██║██╔══╝  ██║   ██║
██║██║ ╚████║██║     ╚██████╔╝
╚═╝╚═╝  ╚═══╝╚═╝      ╚═════╝

      NETWORK INFORMATION TOOL v1.0

""" + Style.RESET_ALL)


def get_local_ip():
    try:
        return socket.gethostbyname(socket.gethostname())
    except:
        return "Unknown"


def get_hostname():
    return socket.gethostname()


def get_public_info():
    try:
        return requests.get("https://ipinfo.io/json", timeout=5).json()
    except:
        return {}


banner()

public = get_public_info()

result = {
    "Hostname": get_hostname(),
    "Local IP": get_local_ip(),
    "Public IP": public.get("ip", "Unknown"),
    "City": public.get("city", "Unknown"),
    "Region": public.get("region", "Unknown"),
    "Country": public.get("country", "Unknown"),
    "ISP": public.get("org", "Unknown"),
    "Coordinates": public.get("loc", "Unknown"),
    "Time Checked": str(datetime.now())
}

print(Fore.GREEN + "\n=== Network Information ===\n")

for key, value in result.items():
    print(Fore.YELLOW + key + ": " + Fore.WHITE + str(value))

if public.get("loc"):
    print(
        Fore.BLUE +
        "\nMap: https://www.google.com/maps?q=" +
        public["loc"]
    )

with open("report.json", "w") as file:
    json.dump(result, file, indent=4)

print(Fore.GREEN + "\n[+] Report saved as report.json")
