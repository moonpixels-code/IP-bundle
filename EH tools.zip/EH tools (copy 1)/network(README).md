# 🌐 Network Information Tool

A lightweight Python utility that displays useful information about your current network connection.

Designed for learning Python, Linux networking, and cybersecurity fundamentals.

---

## Features

- 🖥️ Hostname
- 🏠 Local IP Address
- 🌍 Public IP Address
- 🌎 Country
- 🏙️ City
- 📍 Region
- 🛰️ Approximate Coordinates
- 🏢 ISP Information
- 🎨 Colored Output
- 📄 JSON Report
- 🖥️ ASCII Banner

---

## Installation

Clone the repository:

```bash
git clone https://github.com/yourusername/Network-Information-Tool.git
```

Enter the folder:

```bash
cd Network-Information-Tool
```

Install dependencies:

```bash
pip install -r requirements.txt
```

---

## Usage

```bash
python3 network_info.py
```

Example output:

```
Hostname: kali
Local IP: 192.168.1.15
Public IP: 105.xxx.xxx.xxx
Country: ZA
ISP: Example ISP
Coordinates: -26.20,28.04
```

The program automatically creates:

```
report.json
```

---

## Requirements

- Python 3
- requests
- colorama

---

## Project Structure

```
Network-Information-Tool/

├── network_info.py
├── README.md
├── report.json
├── requirements.txt
├── LICENSE
└── .gitignore
```

---

## Disclaimer

This tool only gathers information about the computer on which it is run and publicly available information about the current internet connection. It does not scan or inspect other devices.

---

## License

MIT License
