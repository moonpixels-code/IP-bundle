#!/usr/bin/env python3

import socket
import json
from datetime import datetime
from colorama import Fore, Style, init

init()


def banner():

    print(Fore.CYAN + r"""

██████╗ ███╗   ██╗███████╗
██╔══██╗████╗  ██║██╔════╝
██║  ██║██╔██╗ ██║███████╗
██║  ██║██║╚██╗██║╚════██║
██████╔╝██║ ╚████║███████║

        DNS LOOKUP TOOL v1.0

""" + Style.RESET_ALL)



def lookup(domain):

    try:

        ip = socket.gethostbyname(domain)


        result = {

            "Domain": domain,
            "IP Address": ip,
            "Checked": str(datetime.now())

        }


        print(
            Fore.GREEN +
            "\n=== DNS Information ==="
        )


        print(
            Fore.YELLOW +
            "Domain: ",
            Fore.WHITE +
            domain
        )


        print(
            Fore.YELLOW +
            "IP: ",
            Fore.WHITE +
            ip
        )


        return result


    except Exception:

        print(
            Fore.RED +
            "Could not resolve:",
            domain
        )

        return None




banner()


domains = input(
    Fore.CYAN +
    "Enter domains separated by commas: "
    +
    Style.RESET_ALL
)


results = []


for domain in domains.split(","):

    domain = domain.strip()

    data = lookup(domain)


    if data:
        results.append(data)



with open(
    "dns_report.json",
    "w"
) as file:

    json.dump(
        results,
        file,
        indent=4
    )


print(
    Fore.GREEN +
    "\n[+] Saved dns_report.json"
)
