# 🔐 Password Strength Checker

A Python-based password security checker that analyzes password strength and provides improvement suggestions.

Built for learning cybersecurity, Python, and password security concepts.

## ✨ Features

- 🔍 Password strength analysis
- 🎨 Colored terminal output
- 🖥️ ASCII banner
- 📊 Security scoring system
- ⚠️ Weak password detection
- 💡 Improvement suggestions
- 📄 JSON report generation

## Example


PASSWORD STRENGTH CHECKER v1.0

Enter password to check:
Hello123


Output:


=== Password Report ===

Strength: Medium
Score: 4

Issues:

No symbols

Suggestions:

Add special characters

[+] Report saved as report.json


## Installation

Clone:

```bash
git clone https://github.com/yourusername/Password-Strength-Checker.git

Enter folder:

cd Password-Strength-Checker

Install requirements:

pip install -r requirements.txt
Usage

Run:

python3 password_checker.py
Project Structure
Password-Strength-Checker/

├── password_checker.py
├── report.json
├── README.md
├── requirements.txt
└── LICENSE
Disclaimer

This tool is for educational purposes only.

Do not use it to collect or store other people's passwords.
