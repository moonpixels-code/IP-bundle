#!/usr/bin/env python3

import json
import whois
from datetime import datetime
from colorama import Fore, Style, init

init()


def banner():

    print(Fore.CYAN + r"""
██╗    ██╗██╗  ██╗ ██████╗ ██╗███████╗
██║    ██║██║  ██║██╔═══██╗██║██╔════╝
██║ █╗ ██║███████║██║   ██║██║███████╗
██║███╗██║██╔══██║██║   ██║██║╚════██║
╚███╔███╔╝██║  ██║╚██████╔╝██║███████║
 ╚══╝╚══╝ ╚═╝  ╚═╝ ╚═════╝ ╚═╝╚══════╝

          WHOIS LOOKUP TOOL v1.0

""" + Style.RESET_ALL)



def lookup(domain):

    try:

        info = whois.whois(domain)


        result = {

            "Domain": domain,
            "Registrar": info.registrar,
            "Creation Date": str(info.creation_date),
            "Expiration Date": str(info.expiration_date),
            "Updated Date": str(info.updated_date),
            "Name Servers": info.name_servers,
            "Country": info.country,
            "Organization": info.org,
            "Checked": str(datetime.now())

        }


        print(
            Fore.GREEN +
            "\n=== WHOIS Information ==="
        )


        for key, value in result.items():

            print(
                Fore.YELLOW +
                f"{key}: "
                +
                Fore.WHITE +
                f"{value}"
            )


        return result


    except Exception as e:

        print(
            Fore.RED +
            "Lookup failed: "
            +
            str(e)
        )

        return None



banner()


domains = input(
    Fore.CYAN +
    "Enter domain(s) separated by commas: "
    +
    Style.RESET_ALL
)


reports = []


for domain in domains.split(","):

    domain = domain.strip()

    if domain:

        result = lookup(domain)

        if result:
            reports.append(result)



with open(
    "whois_report.json",
    "w"
) as file:

    json.dump(
        reports,
        file,
        indent=4
    )


print(
    Fore.GREEN +
    "\n[+] Report saved as whois_report.json"
)
