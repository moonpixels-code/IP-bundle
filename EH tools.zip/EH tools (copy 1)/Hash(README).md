# 🔐 Hash Generator

A lightweight Python tool that generates cryptographic hashes for text using multiple algorithms.

Perfect for learning Python, cybersecurity fundamentals, and integrity verification.

---

## ✨ Features

- MD5
- SHA-1
- SHA-224
- SHA-256
- SHA-384
- SHA-512
- Colored terminal output
- ASCII banner
- JSON report export

---

## Installation

Clone the repository:

```bash
git clone https://github.com/yourusername/Hash-Generator.git
```

Enter the directory:

```bash
cd Hash-Generator
```

Install requirements:

```bash
pip install -r requirements.txt
```

---

## Usage

Run:

```bash
python3 hash_generator.py
```

Example:

```
Enter text to hash:

OpenAI
```

Output:

```
=== Hash Results ===

MD5:
0523b13262b12c215d8009938f5c14f1

SHA256:
8b7d1a31...
```

A report will also be saved as:

```
report.json
```

---

## Project Structure

```
Hash-Generator/
│
├── hash_generator.py
├── report.json
├── README.md
├── requirements.txt
├── LICENSE
└── .gitignore
```

---

## Requirements

- Python 3.10+
- colorama

---

## Disclaimer

This tool generates hashes only.

It does **not** crack, reverse, or decrypt password hashes.

Use responsibly.

---

## License

MIT License
