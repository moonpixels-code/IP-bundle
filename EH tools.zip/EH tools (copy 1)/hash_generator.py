#!/usr/bin/env python3

import hashlib
import json
from datetime import datetime
from colorama import Fore, Style, init

init(autoreset=True)


def banner():
    print(Fore.CYAN + r"""

██╗  ██╗ █████╗ ███████╗██╗  ██╗
██║  ██║██╔══██╗██╔════╝██║  ██║
███████║███████║███████╗███████║
██╔══██║██╔══██║╚════██║██╔══██║
██║  ██║██║  ██║███████║██║  ██║
╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝

      HASH GENERATOR v1.0

""" + Style.RESET_ALL)


def generate_hashes(text):

    return {
        "Original Text": text,
        "MD5": hashlib.md5(text.encode()).hexdigest(),
        "SHA1": hashlib.sha1(text.encode()).hexdigest(),
        "SHA224": hashlib.sha224(text.encode()).hexdigest(),
        "SHA256": hashlib.sha256(text.encode()).hexdigest(),
        "SHA384": hashlib.sha384(text.encode()).hexdigest(),
        "SHA512": hashlib.sha512(text.encode()).hexdigest(),
        "Generated": str(datetime.now())
    }


banner()

text = input(
    Fore.YELLOW +
    "Enter text to hash: " +
    Style.RESET_ALL
)

result = generate_hashes(text)

print(Fore.GREEN + "\n=== Hash Results ===\n")

for key, value in result.items():
    print(
        Fore.CYAN +
        f"{key}: " +
        Fore.WHITE +
        f"{value}"
    )

with open("report.json", "w") as file:
    json.dump(result, file, indent=4)

print(Fore.GREEN + "\n[+] Report saved as report.json")
