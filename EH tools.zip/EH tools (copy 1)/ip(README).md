# 🌍 IP Location Tool

A lightweight Python-based IP geolocation tool that retrieves public IP information such as location estimates, ISP details, and coordinates.

Built for learning Python, networking, APIs, and OSINT concepts.

## ✨ Features

- 🌐 IP address lookup
- 📍 Approximate location information
- 🏢 ISP / organization detection
- 🗺️ Google Maps coordinate link
- 🎨 Colored terminal output
- 🖥️ ASCII banner
- 📄 JSON report export
- 🔎 Supports multiple IP addresses

## 📸 Example


██╗██████╗ ██╗ ██████╗ ██████╗
██║██╔══██╗ ██║ ██╔═══██╗██╔════╝
██║██████╔╝ ██║ ██║ ██║██║
██║██╔═══╝ ██║ ██║ ██║██║
██║██║ ███████╗╚██████╔╝╚██████╗
╚═╝╚═╝ ╚══════╝ ╚═════╝ ╚═════╝

    IP LOCATION TOOL v1.0

Example:


Enter IP address(es) separated by commas:

8.8.8.8,1.1.1.1


Output:


=== IP Information ===

IP: 8.8.8.8
City: Mountain View
Country: US
ISP: Google LLC
Coordinates: xx.x,xx.x

Map:
https://www.google.com/maps?q=xx.x,xx.x

[+] Report saved as report.json


## 📦 Installation

Clone the repository:

```bash
git clone https://github.com/yourusername/IP-Location-Tool.git

Go into the directory:

cd IP-Location-Tool

Install requirements:

pip3 install colorama
🚀 Usage

Run:

python3 mytool.py

Enter a public IP:

8.8.8.8

or multiple IPs:

8.8.8.8,1.1.1.1

The tool will generate:

report.json

containing the lookup results.

📄 JSON Report Example
[
    {
        "IP": "8.8.8.8",
        "Hostname": "dns.google",
        "City": "Mountain View",
        "Region": "California",
        "Country": "US",
        "ISP": "Google LLC",
        "Coordinates": "37.4056,-122.0775"
    }
]
📁 Project Structure
IP-Location-Tool/
│
├── mytool.py
├── report.json
├── README.md
└── LICENSE
🛠️ Requirements
Python 3.x
colorama
Internet connection
⚠️ Disclaimer

This tool provides approximate IP geolocation information.

IP addresses do not reveal exact home addresses. Results may be inaccurate due to:

VPNs
Proxies
Mobile networks
ISP routing

Use this tool only on IP addresses you own or have permission to analyze.

📜 License

This project is licensed under the MIT License.

See the LICENSE file for details.
