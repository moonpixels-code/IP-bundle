# 🌐 DNS Lookup Tool

A simple Python-based DNS lookup tool that retrieves IP address information from domains.

Built for learning Python, networking, and basic OSINT concepts.

## ✨ Features

- 🌐 Domain to IP lookup
- 🎨 Colored terminal output
- 🖥️ ASCII banner
- 📄 JSON report generation
- 🔍 Supports multiple domains
- ⚡ Lightweight and fast

## 📸 Example

██████╗ ███╗ ██╗███████╗
██╔══██╗████╗ ██║██╔════╝
██║ ██║████╗ ██║███████╗
██║ ██║██║╚██╗██║╚════██║
██████╔╝██║ ╚████║███████║

    DNS LOOKUP TOOL v1.0
    
    Example usage:


Enter domains separated by commas:
google.com,github.com


Output:


=== DNS Information ===

Domain: google.com
IP: 142.xxx.xxx.xxx

[+] Saved dns_report.json


## 📦 Installation

Clone the repository:

```bash
git clone https://github.com/yourusername/DNS-Lookup-Tool.git

Go into the folder:

cd DNS-Lookup-Tool

Install requirements:

pip3 install colorama

🚀 Usage

Run:

python3 dns_tool.py

Enter domains:

example.com,google.com

The tool will create:

dns_report.json

📄 Report Example:

[
    {
        "Domain": "google.com",
        "IP Address": "142.xxx.xxx.xxx",
        "Checked": "2026-06-26"
    }
]
containing the lookup results.

📁 Project Structure
DNS-Lookup-Tool/
│
├── dns_tool.py
├── dns_report.json
├── README.md
└── LICENSE
⚠️ Disclaimer

This tool is created for educational purposes and authorized testing only.

Do not use this tool against domains or systems you do not own or do not have permission to test.

📜 License

This project is licensed under the MIT License.

See the LICENSE file for details.

Made with 🐍 Python and ☕ curiosity.

