#!/usr/bin/env python3

import json
import urllib.request
from colorama import Fore, Style, init
from datetime import datetime

init()


def banner():
    print(Fore.CYAN + r"""
 ██╗██████╗     ██╗      ██████╗  ██████╗
 ██║██╔══██╗    ██║     ██╔═══██╗██╔════╝
 ██║██████╔╝    ██║     ██║   ██║██║     
 ██║██╔═══╝     ██║     ██║   ██║██║     
 ██║██║         ███████╗╚██████╔╝╚██████╗
 ╚═╝╚═╝         ╚══════╝ ╚═════╝  ╚═════╝

        IP LOCATION TOOL v1.0
    """ + Style.RESET_ALL)


def get_ip_info(ip):

    url = f"https://ipinfo.io/{ip}/json"

    try:

        with urllib.request.urlopen(url, timeout=10) as response:
            data = json.loads(response.read().decode())


        if "error" in data:
            print(Fore.RED + "Invalid IP: " + ip)
            return None


        result = {

            "IP": data.get("ip"),
            "Hostname": data.get("hostname", "Unknown"),
            "City": data.get("city", "Unknown"),
            "Region": data.get("region", "Unknown"),
            "Country": data.get("country", "Unknown"),
            "ISP": data.get("org", "Unknown"),
            "Coordinates": data.get("loc", "Unknown"),
            "Time Checked": str(datetime.now())

        }


        print(Fore.GREEN + "\n=== IP Information ===")

        for key, value in result.items():

            print(
                Fore.YELLOW +
                f"{key}: " +
                Fore.WHITE +
                f"{value}"
            )


        if data.get("loc"):

            lat, lon = data["loc"].split(",")

            print(
                Fore.BLUE +
                "Map: " +
                f"https://www.google.com/maps?q={lat},{lon}"
            )


        return result


    except Exception as e:

        print(
            Fore.RED +
            "Error: " +
            str(e)
        )

        return None



banner()


ips = input(
    Fore.CYAN +
    "\nEnter IP address(es) separated by commas: "
    + Style.RESET_ALL
)


ip_list = ips.split(",")


reports = []


for ip in ip_list:

    ip = ip.strip()

    if ip:

        result = get_ip_info(ip)

        if result:
            reports.append(result)



with open("report.json", "w") as file:

    json.dump(
        reports,
        file,
        indent=4
    )


print(
    Fore.GREEN +
    "\n[+] Report saved as report.json"
)
